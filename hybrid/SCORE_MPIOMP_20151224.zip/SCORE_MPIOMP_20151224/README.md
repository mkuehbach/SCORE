# SCORE
MPI-parallelized cellular automaton ensemble model for the simulation of primary recrystallization phenomena in 3D
