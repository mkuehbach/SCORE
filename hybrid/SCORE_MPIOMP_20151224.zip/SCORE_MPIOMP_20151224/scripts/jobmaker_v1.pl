#! /usr/bin/perl -w

use strict;

# logcsvanalyzer_v1 <log.x.csv> <ncells maximum that can be infected>
# analyzes node-based CORe2V2 output for: t, Xav, Stotal, logt, log(-ln(1-Xav)), SteigungImJMAKplot, dX<automatengr��e>/dt(1-Xavvorher), q, tr von 50% ausgehend
# autodetects number of compute nodes from first headerline

my $case = shift; $case = &trim($case);		#one particular input file
my $simid = shift; $simid = &trim($simid);	#the job local id
my $ompt = shift; $ompt = &trim($ompt);		#the number of threads desired

#check input
if ($simid <= 0) {print("Invalid simid\n"); exit;}
if ($ompt < 1 || $ompt > 12) {print("Invalid OMP NUM THREADS\n"); exit;}


#general KMPAffinityString
my $kmp = "KMP_AFFINITY=\"explicit,granularity=fine,proclist=[";
for ( my $core = 0; $core < $ompt-1; $core++ ) { $kmp .= "$core,"; }
my $lastcore = $ompt - 1;
$kmp .= "$lastcore],verbose\"";


my $sout = "";
$sout .= "#!/usr/bin/env zsh\n";
$sout .= "\n";
$sout .= "#BSUB -J SCOREHYB\n";
$sout .= "#BSUB -o SCOREHYB.\%J\n";
$sout .= "#BSUB -e SCOREHYB.e\%J\n";
if ( $ompt <= 4 ) { $sout .= "#BSUB -W 1\:30\n"; }
else { $sout .= "#BSUB -W 0\:30\n"; }		
$sout .= "#BSUB -M 20000\n";
$sout .= "#BSUB -a intelmpi\n";
$sout .= "module switch openmpi intelmpi\n";
$sout .= "#BSUB -n 1\n";
$sout .= "#BSUB -R \"span[ptile=1]\"\n";
$sout .= "#BSUB -m mpi-s\n";
$sout .= "#BSUB -x\n";
$sout .= "#BSUB -R \"select[hpcwork]\"\n";
$sout .= "#BSUB -P jara0076\n";
$sout .= "\n";
$sout .= "\### utilize intel mpi and compilers to compile into the code explicit threadcore pinning\n";
#$sout .= "module unload openmpi\n";
#$sout .= "module load intelmpi/5.0\n";
$sout .= "echo \"SCOREHyb intel/intelmpi, exclusive, ptile=1, -O2 with the threads pinned to physical cores\"\n";
$sout .= "module load intel/14.0\n";
$sout .= "export $kmp\n";
$sout .= "echo \$KMP_AFFINITY\n";
$sout .= "\n";
$sout .= "mkdir -p runs/$simid\n";
$sout .= "cd runs/$simid\n";
$sout .= "\n";
$sout .= "cmake -DCMAKE_BUILD_TYPE=Release ..\n";
$sout .= "make\n";
$sout .= "\n";
$sout .= "export OMP_NUM_THREADS=\"$ompt\"\n";
$sout .= "echo \$OMP_NUM_THREADS\n";

$sout .= "ulimit -u unlimited\n";
$sout .= "\n";

$sout .= "\$MPIEXEC \$FLAGS_MPI_BATCH scorehyb_intel14O2 ../SCORE.Input.$case.uds $simid 2>KMPAff.Case.$case.SimID.$simid.txt\n";
	
open ( RESULTS, ">scorehyb_$simid.sh") || die ( "ERROR.open.file=(scorehyb_$simid.sh).mode=(r)");
print RESULTS $sout;
close ( RESULTS );
$sout = ""; 



	
###################################################################################################
sub trim {
	my $str = shift;
	$str =~ s/^\s+//;	
	$str =~ s/\s+$//;	
	return ( $str );
}

