//SCORE automaton developed by M K{\"u}hbach, 2014/2015, for questions and details contact markus.kuehbach@rwth-aachen.de

#include "SCORE_Kernel.h"


//user-interaction passed arguments
#define INPUTFILE				1
#define	ID						2


using namespace std;

//PRECAUTIONS::
//MPI library is required to work support thread MPI when within a parallel region MPI is being called!


int main(int argc, char** argv) {

	int simid = atoi(argv[ID]);
	if ( simid < 1 && simid >= INTEGER_RANGE_MAX ) { cout << "ERROR::Invalid simulation ID to identify files." << endl; return 0; }

	ensembleHdlP myensemble = new ensembleHdl;
	myensemble->simid = simid;

	if( !myensemble->open(READ, argv[INPUTFILE], &(myensemble->score_input)) ) { cout << "ERROR::Reading input file." << endl; }

MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &myensemble->nRanks);
	MPI_Comm_rank(MPI_COMM_WORLD, &myensemble->myRank);
	myensemble->prof_t0 = MPI_Wtime();

//preparation phase
	myensemble->init_ensprng( true ); //true - seed is (-1*myRank)-1, false - all the same default seed
	myensemble->init_mpidatatypes();
	myensemble->init_parameter();
	myensemble->init_processing();
	myensemble->init_defgpool();
	myensemble->init_rxgpool();

	//no Barrier necessary when distributeWorkOnRanksOnRanks separates work without iteratively packing/work partitioning
	myensemble->init_distributeWorkOnRanks();
	myensemble->init_distributeWorkOnStartedThreads();
	//no Barrier necessary because now each process can evolve independently the associated automata

	myensemble->SIMULATE_myCAs();

	//MPIBarrier necessary,before gathering all results again at the local process level
	MPI_Barrier( MPI_COMM_WORLD );
	myensemble->prof_tstartpp = MPI_Wtime();

	myensemble->postprocess_write_mycas();

//cout << myensemble->myRank << " beyond the Barrier!" << endl;

	myensemble->postprocess_init();
	myensemble->postprocess_rediscr_kinetics();
	myensemble->postprocess_rediscr_macrotexture();
	myensemble->postprocess_rediscr_finalgrainsizedistribution();

	myensemble->destroy_myCAs();

	myensemble->prof_tend = MPI_Wtime();
	if ( myensemble->myRank == MASTER ) { 
		cout << "Simulation finished with some new insights into pRX, skal." << endl;
		cout << "MASTER exiting MPI_init prior to starting postprocessing seconds=" << setprecision(6) << (myensemble->prof_tstartpp - myensemble->prof_t0) << endl;
		cout << "MASTER starting postprocessing and prior to MPI_Finalize seconds=" << setprecision(6) << (myensemble->prof_tend - myensemble->prof_tstartpp) << endl;
		cout << "MASTER total time seconds=" << setprecision(6) << (myensemble->prof_tend - myensemble->prof_t0) << endl;
	}
MPI_Finalize();

	fclose(myensemble->score_input);
	delete myensemble;

	return 0;
}



//output size of the datastructures
/*
	if (myensemble->myRank == MASTER) { 
		cout << "SCORe - Statistical Cellular Operator Ensemble Model for Recrystallization." << endl;
		cout << "defcell=" << sizeof(defcell) << endl;
		cout << "cell=" << sizeof(cell) << endl;
		cout << "rxg=" << sizeof(rxg) << endl;
		cout << "defg=" << sizeof(defg) << endl;
		cout << "ori=" << sizeof(ori) << endl;
		cout << "qsymmfcc=" << sizeof(qsymm_fcc) << endl;
		cout << "cadefg=" << sizeof(cadefg) << endl;
		cout << "carxg=" << sizeof(carxg) << endl;
		cout << "ideal=" << sizeof(ideal) << endl;
		cout << "loginfophys=" << sizeof(loginfo_ca_physics) << endl;
		cout << "defgseed=" << sizeof(defgseed) << endl;
		cout << "cellsBndFast=" << sizeof(cellsBndFast) << endl;
		cout << "bndFaceFast=" << sizeof(bndFaceFast) << endl;
		cout << "bndColumnFast=" << sizeof(bndColumnFast) << endl;
		cout << "loginfogrevo=" << sizeof(loginfo_grainevo_ca) << endl;
		cout << "loginfo_rxfront=" << sizeof(loginfo_rxfrontstats_ca) << endl;
		cout << "ensHdl=" << sizeof(ensembleHdl) << endl;
		cout << "caHdl=" << sizeof(caHdl) << endl;
	}
*/

	/*uint32_t nlim = 4294967295;
	uint32_t n = (uint32_t) atof(argv[1]);
	uint32_t nbx = 1625;
	uint32_t nby = 1625;
	uint32_t nbz = 1625;
	uint32_t nbxy = nbx * nby;
	uint32_t nbxyz = nbx * nby * nbz;
	cout << "Input was = " << atoi(argv[1]) << " uint32_t = " << n << " nlim = " << nlim << " nbxy = " << nbxy << " nbxyz = " << nbxyz << endl;
	//for ( uint32_t n = 0; n < nlim; ++n ) {
		uint32_t iz = n / nbxy;
		uint32_t rem = n - (nbxy * iz);
		uint32_t iy = rem / nbx;
		uint32_t ix = rem - (nbx * iy);
	cout << "ix\t\tiy\t\tiz----rem\t\t\t" << ix << "\t\t" << iy << "\t\t" << iz << "----" << rem << endl;
	cout << "sizeof(uint32_t) = " << sizeof(uint32_t) << endl;
	return 0;*/
