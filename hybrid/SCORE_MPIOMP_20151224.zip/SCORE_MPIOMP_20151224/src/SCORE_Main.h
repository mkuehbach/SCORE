//SCORE automaton developed by M K{\"u}hbach, 2014/2015, for questions and details contact markus.kuehbach@rwth-aachen.de

#ifndef __SCORE_MAIN_H_INCLUDED__
#define	__SCORE_MAIN_H_INCLUDED__



#endif
